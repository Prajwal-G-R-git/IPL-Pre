// ═══════════════════════════════════════════════
// leaderboard.js — Leaderboard Fetching & Rendering
// ═══════════════════════════════════════════════

async function loadLeaderboard() {
  const listEl = document.getElementById('leaderboard-list');
  listEl.innerHTML = `<div class="loading-state"><div class="loader"></div><p>Loading rankings...</p></div>`;

  try {
    const { data: users, error } = await supabaseClient
      .from('users')
      .select('id, username, total_points, streak, risk_title')
      .order('total_points', { ascending: false })
      .limit(50);

    if (error) throw error;

    if (!users || users.length === 0) {
      listEl.innerHTML = `<div class="empty-state">No players yet. Be the first to predict! 🏏</div>`;
      return;
    }

    listEl.innerHTML = '';

    users.forEach((user, index) => {
      const rank = index + 1;
      const row = document.createElement('div');
      row.className = `leaderboard-row rank-${rank <= 3 ? rank : 'other'}`;
      if (user.id === currentUser.id) {
        row.style.borderLeft = '3px solid var(--accent)';
      }

      const rankDisplay = rank === 1 ? '🥇' : rank === 2 ? '🥈' : rank === 3 ? '🥉' : rank;

      row.innerHTML = `
        <span class="lb-rank">${rankDisplay}</span>
        <div>
          <div class="lb-name">${escapeHtml(user.username)}</div>
          ${user.id === currentUser.id ? '<div style="font-size:11px;color:var(--accent);font-family:var(--font-cond);letter-spacing:1px;">YOU</div>' : ''}
        </div>
        <span>
          <span class="lb-title-badge">${escapeHtml(user.risk_title || 'Rookie')}</span>
        </span>
        <span class="lb-streak">${user.streak > 0 ? `🔥 ${user.streak}` : '—'}</span>
        <span class="lb-points">${user.total_points}</span>
      `;

      listEl.appendChild(row);
    });

  } catch (err) {
    listEl.innerHTML = `<div class="empty-state">⚠️ Could not load leaderboard.<br><small>${err.message}</small></div>`;
  }
}

// ─── Load profile page data ───
async function loadProfileData() {
  if (!currentUser || !currentProfile) return;

  document.getElementById('profile-username').textContent = currentProfile.username;
  document.getElementById('profile-title-badge').textContent = currentProfile.risk_title || 'Rookie';
  document.getElementById('profile-points').textContent = currentProfile.total_points;
  document.getElementById('profile-streak').textContent = `${currentProfile.streak} 🔥`;

  // Fetch predictions for this user
  const { data: preds, error } = await supabaseClient
    .from('predictions')
    .select('*, matches(team1, team2, match_time)')
    .eq('user_id', currentUser.id)
    .order('created_at', { ascending: false })
    .limit(10);

  if (error || !preds) return;

  document.getElementById('profile-pred-count').textContent = preds.length;

  const historyEl = document.getElementById('prediction-history');
  if (!preds.length) {
    historyEl.innerHTML = `<div class="empty-state">No predictions yet. Head to the dashboard!</div>`;
    return;
  }

  historyEl.innerHTML = '';
  preds.forEach(pred => {
    const item = document.createElement('div');
    item.className = 'pred-history-item';

    const matchLabel = pred.matches
      ? `${pred.matches.team1} vs ${pred.matches.team2}`
      : pred.match_id;

    item.innerHTML = `
      <div>
        <div class="pred-match-name">${escapeHtml(matchLabel)}</div>
        <div class="pred-winner-pick">Winner pick: <strong>${escapeHtml(pred.predicted_winner || '—')}</strong></div>
      </div>
      ${pred.risky_prediction
        ? `<span class="pred-risky-tag">🔥 ${escapeHtml(pred.risky_prediction)}</span>`
        : ''
      }
    `;
    historyEl.appendChild(item);
  });
}

// ─── Simple HTML escape ───
function escapeHtml(str) {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
