// ═══════════════════════════════════════════════
// matches.js — Match Loading & Card Rendering
// ═══════════════════════════════════════════════

let allMatches = [];
let userPredictions = {}; // match_id → prediction object

// ─── Load all matches from Supabase ───
async function loadMatches() {
  const container = document.getElementById('matches-container');
  container.innerHTML = `<div class="loading-state"><div class="loader"></div><p>Loading matches...</p></div>`;

  try {
    // Fetch matches ordered by time
    const { data: matches, error } = await supabaseClient
      .from('matches')
      .select('*')
      .order('match_time', { ascending: true });

    if (error) throw error;

    allMatches = matches || [];

    // Fetch this user's predictions
    const { data: preds } = await supabaseClient
      .from('predictions')
      .select('*')
      .eq('user_id', currentUser.id);

    // Build lookup map
    userPredictions = {};
    (preds || []).forEach(p => { userPredictions[p.match_id] = p; });

    renderMatchCards();

  } catch (err) {
    container.innerHTML = `<div class="empty-state">⚠️ Could not load matches. Check your Supabase config.<br><small>${err.message}</small></div>`;
  }
}

// ─── Render match cards ───
function renderMatchCards() {
  const container = document.getElementById('matches-container');

  if (!allMatches.length) {
    container.innerHTML = `<div class="empty-state">No matches scheduled yet. Check back soon! 🏏</div>`;
    return;
  }

  container.innerHTML = '';

  allMatches.forEach(match => {
    const card = buildMatchCard(match);
    container.appendChild(card);
  });
}

// ─── Build a single match card element ───
function buildMatchCard(match) {
  const card = document.createElement('div');
  card.className = 'match-card';
  card.id = `match-${match.match_id}`;

  const now = new Date();
  const matchTime = new Date(match.match_time);
  const isStarted = now >= matchTime;
  const isCompleted = !!match.result;
  const predicted = !!userPredictions[match.match_id];

  // Status
  let statusBadge = '';
  let predictBtn = '';

  if (isCompleted) {
    statusBadge = `<span class="match-badge badge-completed">Completed</span>`;
    predictBtn = `<span class="btn-predict done" style="pointer-events:none">Finished</span>`;
    card.classList.add('disabled');
  } else if (isStarted) {
    statusBadge = `<span class="match-badge badge-live">🔴 Live</span>`;
    predictBtn = `<span class="btn-predict done" style="pointer-events:none">Locked 🔒</span>`;
    card.classList.add('disabled');
  } else if (predicted) {
    statusBadge = `<span class="match-badge badge-predicted">✅ Predicted</span>`;
    predictBtn = `<button class="btn-predict done" onclick="openPredictionModal('${match.match_id}')">Edit ✏️</button>`;
    card.classList.add('predicted');
  } else {
    statusBadge = `<span class="match-badge badge-upcoming">Upcoming</span>`;
    predictBtn = `<button class="btn-predict" onclick="openPredictionModal('${match.match_id}')">Predict →</button>`;
  }

  // Format time
  const timeStr = matchTime.toLocaleString('en-IN', {
    month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit',
    timeZone: 'Asia/Kolkata'
  });

  // Countdown
  const timeUntil = isStarted ? '' : getCountdown(matchTime);

  card.innerHTML = `
    <div class="match-status">
      ${statusBadge}
      <span class="match-time">${timeStr} IST</span>
    </div>

    <div class="match-teams">
      <span class="team-name">${match.team1}</span>
      <span class="vs-divider">VS</span>
      <span class="team-name">${match.team2}</span>
    </div>

    <div class="match-footer">
      <div>
        <div class="match-venue">🏟️ ${match.venue || 'TBD'}</div>
        ${timeUntil ? `<div class="match-time" style="margin-top:4px; color: var(--accent)">⏱ ${timeUntil}</div>` : ''}
      </div>
      ${predictBtn}
    </div>
  `;

  return card;
}

// ─── Countdown timer string ───
function getCountdown(matchTime) {
  const diff = matchTime - new Date();
  if (diff <= 0) return null;

  const hours = Math.floor(diff / 1000 / 3600);
  const mins = Math.floor((diff / 1000 / 60) % 60);

  if (hours >= 24) {
    const days = Math.floor(hours / 24);
    return `${days}d ${hours % 24}h away`;
  }
  return `${hours}h ${mins}m to go`;
}

// ─── Seed demo matches (call once via console if needed) ───
async function seedDemoMatches() {
  const demoMatches = [
    {
      match_id: 'IPL2025_M1',
      team1: 'CSK',
      team2: 'MI',
      match_time: new Date(Date.now() + 3600 * 2 * 1000).toISOString(), // 2hrs from now
      venue: 'Chepauk, Chennai',
      result: null
    },
    {
      match_id: 'IPL2025_M2',
      team1: 'RCB',
      team2: 'KKR',
      match_time: new Date(Date.now() + 3600 * 26 * 1000).toISOString(), // Tomorrow
      venue: 'Chinnaswamy, Bangalore',
      result: null
    },
    {
      match_id: 'IPL2025_M3',
      team1: 'SRH',
      team2: 'DC',
      match_time: new Date(Date.now() + 3600 * 50 * 1000).toISOString(),
      venue: 'Rajiv Gandhi Stadium, Hyderabad',
      result: null
    },
    {
      match_id: 'IPL2025_M4',
      team1: 'RR',
      team2: 'LSG',
      match_time: new Date(Date.now() + 3600 * 74 * 1000).toISOString(),
      venue: 'Sawai Mansingh Stadium, Jaipur',
      result: null
    },
    {
      match_id: 'IPL2025_M5',
      team1: 'GT',
      team2: 'PBKS',
      match_time: new Date(Date.now() + 3600 * 98 * 1000).toISOString(),
      venue: 'Narendra Modi Stadium, Ahmedabad',
      result: null
    },
  ];

  const { error } = await supabaseClient.from('matches').upsert(demoMatches);
  if (error) {
    console.error('Seed error:', error);
  } else {
    console.log('✅ Demo matches seeded!');
    await loadMatches();
  }
}
